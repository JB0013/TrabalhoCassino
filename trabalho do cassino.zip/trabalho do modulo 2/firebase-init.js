const firebaseConfig = {
    apiKey: "AIzaSyAWF4EH5Ujz45tP_r387mqiFq9TtWIoaAY",
    authDomain: "trabalho-estrutura-de-dados.firebaseapp.com",
    projectId: "trabalho-estrutura-de-dados",
    storageBucket: "trabalho-estrutura-de-dados.appspot.com",
    messagingSenderId: "394136957449",
    appId: "1:394136957449:web:6094c373838c3f9ca1fed8"
};
firebase.initializeApp(firebaseConfig);