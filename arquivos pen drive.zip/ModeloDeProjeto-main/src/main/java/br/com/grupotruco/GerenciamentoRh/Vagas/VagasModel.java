package br.com.grupotruco.GerenciamentoRh.Vagas;

import java.time.LocalDateTime;
import java.util.UUID;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity(name = "tb_funcionario")
public class VagasModel {
    @Id
    @GeneratedValue(generator = "UUID")
    private UUID id;
    private String Titulo_Vaga;
    private String Descricao_Vaga;
    private String Status_Vaga;
    
    
     @CreationTimestamp
    private LocalDateTime createdAt;
}