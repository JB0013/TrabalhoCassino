package br.com.grupotruco.GerenciamentoRh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import br.com.grupotruco.GerenciamentoRh.GerenciamentoRhApplication;

@SpringBootApplication
public class GerenciamentoRhApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerenciamentoRhApplication.class, args);
	}
}
