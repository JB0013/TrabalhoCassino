package br.com.joaovitor.todoLists.Vagas;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Entity;
import lombok.Data;

@Data
@Entity(name = "tb_funcionario")
public class VagasModel {
    private String Titulo_Vaga;
    private String Descricao_Vaga;
    private String Status_Vaga;
    
    
     @CreationTimestamp
    private LocalDateTime createdAt;
}