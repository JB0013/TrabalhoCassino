package br.com.joaovitor.todoLists;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoListsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoListsApplication.class, args);
	}

}
