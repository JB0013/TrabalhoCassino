package br.com.joaovitor.todoLists;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoListsApplicationTests {

	@Test
	void contextLoads() {
	}

}
