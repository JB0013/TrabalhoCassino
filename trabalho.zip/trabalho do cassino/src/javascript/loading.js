function showLoading() {
    const div = document.createElement("div");
    div.style.add("background-image:'../imagens/ZKZg.gif'",);

    document.body.appendChild(div);
}

function hideLoading() {
    const loadings = document.getElementsByClassName("loading");
    if (loadings.length) {
        loadings[0].remove();
    }
}